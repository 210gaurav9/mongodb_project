<section class="fdes">
		<div class="section white center">
			<h2 class="header" style="padding:20px; padding-bottom: 30px;">Resturant Powered By NMIT</h2>
            <h2 class="header" style="padding:20px; padding-bottom: 30px;">PROJECT BY</h2>
            <h2 class="header" style="padding:20px; padding-bottom: 30px;">NMIT ISE STUDENT'S GROUP</h2>
		      <div class="row container center">
		        <div class="col center l8 s12">
		        	<p>NITTEFOOD_MART is one of only a handful of brands that command instant recognition in virtually every country in the world. It has more than 30,000 restaurants in over 119 countries, serving around 50 million people every day. All businesses face challenges every day. One of the major challenges facing NITTEFOOD_MART is managing stock. Stock management involves creating a balance between meeting customers' needs whilst at the same time minimising waste. Waste is reduced by:<br>
                        <p></p><br>
1.Accurate forecasting of demand so that products do not have to be thrown away as often.<br>
2.Accurate stock control of the raw materials.<br>
                         <p></p><br>
Stock management involves creating a balance between meeting customers' needs whilst at the same time minimising waste. This is an increasingly tough balancing act. As customer tastes change, NITTEFOOD_MART needs to increase the range of new products it offers, so the challenge of reducing waste becomes even greater.</p>
		        </div>
		        <div class="col center l4 s12">
		        	<img height="300" width="auto" style="object-fit: contain;" src="images/17964.jpg" alt="">
		        </div>
		        
		      </div>
	</section>