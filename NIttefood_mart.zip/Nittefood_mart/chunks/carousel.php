<section class="fcarousel">
		<div class="carousel carousel-slider myslider">
	    <a class="carousel-item" href="#one!"><img src="images/banner4.jpg"></a>
	    <a class="carousel-item" href="#two!"><img src="images/banner3.jpg"></a>
	    <a class="carousel-item" href="#three!"><img src="images/banner2.jpg"></a>
	    <a class="carousel-item" href="#four!"><img src="images/banner1.jpg"></a>
	  </div>
  </section>