<div class="row">
			
			<div class="col s2 left-sidebar" id="left-sidebar">

				<div class="row">
					<div class="col">
                        <h5 class="heading-name" style="background-color:DodgerBlue;"><b>NITTEFOOD_MART</b></h5>
                        <h5 class="heading-name" style="background-color:green;"><center><b>PROJECT BY</b></center></h5>
                        <h5 class="heading-name" style="background-color:DodgerBlue;"><b>NMIT ISE STUDENT'S GROUP</b></h5>
					</div>
				</div>
				<ul class="nav nav-sidebar list-group">
				    <li class="list-group-item active"><a href="food-list.php">Foods </a></li>
				    <li class="list-group-item"><a href="category-list.php">Category</a></li>
				    <li class="list-group-item"><a href="order-list.php">Orders</a></li>
				    <li class="list-group-item modal-trigger" data-target="modal1"><a href="#">About</a></li>
				  </ul>
			</div>