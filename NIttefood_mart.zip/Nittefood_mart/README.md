THIS PROJECT IS DONE BY:-
1.PAWAN KUMAR(1NT17IS121) and group

# nittefood_mart

A Simple Demo Resturant Management System Project in PHP


A pure custom PHP Project. Build for reference!

					ADMIN
USERNAME:-nittefood_mart@gmail.com
PASSWORD:-nitte@123
                    USER
USERNAME:-prempawan98@gmail.com
PASSWORD:-Pawan@12345